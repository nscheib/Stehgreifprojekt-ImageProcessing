package filters;

/**
 * 
 * Auflistung der verfuegbaren Farbbaender
 * @author Lukas Richter, Benedikt Ringlein
 *
 */
public enum ColorBand {
	RED, GREEN, BLUE
}
